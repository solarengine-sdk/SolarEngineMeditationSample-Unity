using UnityEngine;
using SolarEngine;
using AnyThinkAds.Api;

namespace SolarEngineMeditationSample.Wrappers.Taku
{
    /// <summary>
    /// Taku -> SolarEngine tracker bridge for Unity
    /// Only exposes trackAdImpression(ImpressionAttributes attributes)
    /// </summary>
    public static class TakuSolarEngineTracker
    {
        public static void trackAdImpression(TakuAdType adType, ATCallbackInfo callbackInfo)
        {
            Debug.Log("TakuSolarEngineTracker.trackAdImpression() called");

            var attributes = new ImpressionAttributes
            {
                ad_platform = callbackInfo != null ? callbackInfo.network_name : "Taku",
                mediation_platform = "Taku",
                ad_appid = "",
                ad_id = callbackInfo != null ? callbackInfo.network_placement_id : "",
                ad_type = (int) adType,
                ad_ecpm = callbackInfo != null ? callbackInfo.publisher_revenue : 0,
                currency_type = callbackInfo != null ? callbackInfo.currency : "CNY",
                is_rendered = true,
                customProperties = null
            };

            Analytics.trackAdImpression(attributes);
        }
    }
}


